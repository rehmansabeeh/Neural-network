# -*- coding: utf-8 -*-
"""
Created on Wed Apr 10 23:00:51 2019

@author: YourAverageSciencePal
"""
import numpy as np
import sys
# import cv2
import os
from PIL import Image
import time
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from random import *
from sklearn.preprocessing import OneHotEncoder
'''
Depending on your choice of library you have to install that library using pip
'''


'''
Read chapter on neural network from the book. Most of the derivatives,formulas
are already there.
Before starting this assignment. Familarize yourselves with np.dot(),
What is meant by a*b in 2 numpy arrays.
What is difference between np.matmul and a*b and np.dot.
Numpy already has vectorized functions for addition and subtraction and even for division
For transpose just do a.T where a is a numpy array
Also search how to call a static method in a class.
If there is some error. You will get error in shapes dimensions not matched
because a*b !=b*a in matrices
'''


class NeuralNetwork():
    @staticmethod
    # note the self argument is missing i.e. why you have to search how to use static methods/functions
    def cross_entropy_loss(y_pred, y_true):
        sum_score = 0.0
        for i in range(len(y_true)):
            sum_score += y_true[i] * np.log(1e-15 + y_pred[i])
        mean_sum_score = 1.0 / len(y_pred) * sum_score
        mean_sum_score = mean_sum_score*-1
        return mean_sum_score
        '''implement cross_entropy loss error function here
        Hint: Numpy has a sum function already
        Numpy has also a log function
        Remember loss is a number so if y_pred and y_true are arrays you have to sum them in the end
        after calculating -[y_true*log(y_pred)]'''
        return None

    @staticmethod
    def accuracy(y_pred, y_true):
        counter = 0
        for i in range(len(y_pred)):
            # print(y_pred[i], " == ", y_true[i])
            # print(y_pred[i])
            # print(y_true[i])
            if float(y_pred[i]) == float(y_true[i]):
                # print('match')
                counter = counter + 1
        # print(counter)
        acc = float(float(counter)/len(y_pred))
        # print(acc)
        '''function to calculate accuracy of the two lists/arrays
        Accuracy = (number of same elements at same position in both arrays)/total length of any array
        Ex-> y_pred = np.array([1,2,3]) y_true=np.array([1,2,4]) Accuracy = 2/3*100 (2 Matches and 1 Mismatch)'''
        return acc*100

    @staticmethod
    def softmax(x):
        temp = np.exp()
        ans = temp/temp.sum()
        return ans
        '''Implement the softmax function using numpy here
        Hint: Numpy sum has a parameter axis to sum across row or column. You have to use that
        Use keepdims=True for broadcasting
        You guys should have a pretty good idea what the size of returned value is.
        '''
        # return None

    @staticmethod
    def sigmoid(x):
        '''Implement the sigmoid function using numpy here
        Sigmoid function is 1/(1+e^(-x))
        Numpy even has a exp function search for it.Eh?
        '''
        ans = 1/(1 + np.exp(-x))
        return ans

    def __init__(self):
        '''Creates a Feed-Forward Neural Network.
        "nodes_per_layer" is a list containing number of nodes in each layer (including input layer)
        "num_layers" is the number of layers in your network
        "input_shape" is the shape of the image you are feeding to the network
        "output_shape" is the number of probabilities you are expecting from your network'''

        self.num_layers = 3  # includes input layer
        self.nodes_per_layer = [784, 30, 10]
        self.input_shape = self.nodes_per_layer[0]
        self.output_shape = self.nodes_per_layer[-1]
        self.__init_weights(self.nodes_per_layer)

    def __init_weights(self, nodes_per_layer):
        '''Initializes all weights and biases between -1 and 1 using numpy'''
        self.weights_ = []
        self.biases_ = []
        temp_bias = []
        for i in range(30):
            rnd = np.random.default_rng()
            val_bias = rnd.uniform(-1, 1)
            val_bias = 0
            temp_bias.append(val_bias)
        self.biases_.append(np.array(temp_bias))
        temp_bias = []
        for i in range(10):
            rnd = np.random.default_rng()
            val_bias = rnd.uniform(-1, 1)
            # val_bias = random()
            val_bias = 0
            temp_bias.append(val_bias)
        self.biases_.append(np.array(temp_bias))

        for i, j in enumerate(nodes_per_layer):
            if i == 0:
                # skip input layer, it does not have weights/bias
                continue
            for l in range(j):
                rnd = np.random.default_rng()
                weight_matrix = rnd.uniform(-1, 1, (nodes_per_layer[i-1], j))
            self.weights_.append(weight_matrix)
            weight_matrix = []

    def fit(self, Xs, Ys, epochs, lr):
        '''Trains the model on the given dataset for "epoch" number of itterations with step size="lr".
        Returns list containing loss for each epoch.'''
        history = []
        plot_list_time = []
        plot_list_acc = []
        temp_labels = self.generate_labels(Ys)
        print("Started Training.....")
        # print(len(Xs))
        for j in range(0, epochs):
            time1 = time.time()
            temp_pred = []
            for i in range(len(Xs)):
                # print(i)
                activations = self.forward_pass(Xs[i])
                deltas = self.backward_pass(temp_labels[i], activations, Xs[i])
                self.weight_update(deltas, Xs[i], lr)
                pred = self.predict(activations[-1])
                temp_pred.append(str(pred[0]))
            temp_accuracy = self.accuracy(temp_pred, Ys)

            time2 = time.time()
            time3 = time2 - time1
            print("Epoc number ", j+1, " : =======> ", temp_accuracy, "%")
            plot_list_acc.append(temp_accuracy)
            plot_list_time.append(time3)

        self.savePlot(plot_list_acc, plot_list_time)
        print("Done with training.")
        return history

    def forward_pass(self, input_data):
        '''Executes the feed forward algorithm.
        "input_data" is the input to the network in row-major form
        Returns "activations", which is a list of all layer outputs (excluding input layer of course)
        What is activation?
        In neural network you have inputs(x) and weights(w).
        What is first layer? It is your input right?
        A linear neuron is this: y = w.T*x+b =>T is the transpose operator
        A sigmoid neuron activation is y = sigmoid(w1.T*x+b1) for 1st hidden layer
        Now for the last hidden layer the activation y = sigmoid(w2.T*y+b2).
        '''
        activations = []

        # print(self.weights_[0].shape)
        # print(input_data.shape)
        y1 = input_data.dot(self.weights_[0])
        y_activation = NeuralNetwork.sigmoid(y1)
        activations.append(y_activation)

        y2 = y1.dot(self.weights_[1])
        y2_activation = NeuralNetwork.sigmoid(y2)
        activations.append(y2_activation)
        # print('Forward propagation successful')
        # print(np.array(activations).shape)
        return activations

    def backward_pass(self, targets, layer_activations, val):
        '''Executes the backpropogation algorithm.
        "targets" is the ground truth/labels
        "layer_activations" are the return value of the forward pass step
        Returns "deltas", which is a list containing weight update values for all layers (excluding the input layer of course)
        You need to work on the paper to develop a generalized formulae before implementing this.
        Chain rule and derivatives are the pre-requisite for this part.
        '''
        deltas = []

        temp_layer = layer_activations[1] - targets
        temp_activation = layer_activations[0].reshape(30, 1)
        temp_layer = temp_layer.reshape(10, 1).T
        delt_1 = np.dot(temp_activation, temp_layer)

        temp_layer = temp_layer.T
        temp_layer_2 = np.dot(self.weights_[1], temp_layer)
        temp_layer_2 = temp_layer_2.T

        temp_sig = np.dot(val, self.weights_[0])
        sig_val = NeuralNetwork.sigmoid(temp_sig)
        value_sigmoid = sig_val * (1 - sig_val)

        shape = value_sigmoid * temp_layer_2

        # in order to match the shape for multiplications to get delta 2
        temp_shape = shape.reshape(30, 1).T
        val_shape = val.reshape(784, 1)
        delt_2 = np.dot(val_shape, temp_shape)

        deltas = [delt_1, delt_2]
        # print(deltas)
        return deltas

    def weight_update(self, deltas, layer_inputs, lr):
        '''Executes the gradient descent algorithm.
        "deltas" is return value of the backward pass step
        "layer_inputs" is a list containing the inputs for all layers (including the input layer)
        "lr" is the learning rate
        You just have to implement the simple weight update equation.

        '''
        # print(deltas[1].shape)
        # print(self.weights_[1].shape)
        # print(self.weights_[0].shape)
        self.biases_[1] = self.biases_[1] - lr * (deltas[0].sum(axis=0))
        self.biases_[0] = self.biases_[0] - lr * (deltas[1].sum(axis=0))
        self.weights_[0] = self.weights_[0] - (lr * deltas[1])
        self.weights_[1] = self.weights_[1] - (lr * deltas[0])

        # print('ended')

    def predict(self, Xs):
        '''Returns the model predictions (output of the last layer) for the given "Xs".'''
        predictions = []
        temp = np.argmax(Xs)
        predictions.append(temp)
        return predictions

    def evaluate(self, Xs, Ys):
        '''Returns appropriate metrics for the task, calculated on the dataset passed to this method.'''
        temp_pred = []
        for i in range(len(Xs)):
            activations = self.forward_pass(Xs[i])
            pred = self.predict(activations[-1])
            temp_pred.append(str(pred[0]))
        acc = self.accuracy(temp_pred, Ys)
        loss = 100-acc
        return loss, acc

    def give_images(self, file_data, file_labels):
        '''Returns the images and labels from the listDirImages list after reading
        Hint: Use os.listdir(),os.getcwd() functions to get list of all directories
        in the provided folder. Similarly os.getcwd() returns you the current working
        directory.
        For image reading use any library of your choice. Commonly used are opencv,pillow but
        you have to install them using pip
        "images" is list of numpy array of images
        labels is a list of labels you read
        '''
        data = []
        temp_num = []
        end_bracket = False
        file2read = open(file_data, 'r')
        temp_reading = file2read.read().splitlines()
        for i in range(len(temp_reading)):
            temp_data = temp_reading[i].strip('[')
            for j in range(len(temp_data)):
                if temp_data[j] == ']':
                    end_bracket = True
                    temp_data = temp_data.strip(']')
            temp_data = temp_data.split()
            for j in range(len(temp_data)):
                temp_val = float(temp_data[j])/255.0
                temp_num.append(temp_val)
            if end_bracket == True:
                end_bracket = False
                data.append(temp_num)
                temp_num = []

        file2read.close()
        # to read labels
        file2read_labels = open(file_labels, 'r')
        labels = file2read_labels.read().splitlines()
        file2read_labels.close()
        data = np.array(data)
        # data = data/255.0
        return data, labels

    def generate_labels(self, labels):
        '''Returns your labels into one hot encoding array
        labels is a list of labels [0,1,2,3,4,1,3,3,4,1........]
        Ex-> If label is 1 then one hot encoding should be [0,1,0,0,0,0,0,0,0,0]
        Ex-> If label is 9 then one hot encoding shoudl be [0,0,0,0,0,0,0,0,0,1]
        Hint: Use sklearn one hot-encoder to convert your labels into one hot encoding array
        "onehotlabels" is a numpy array of labels. In the end just do np.array(onehotlabels).
        '''
        onehot_encoder = OneHotEncoder(sparse=False)
        labels = np.array(labels)
        labels = labels.reshape(len(labels), 1)
        onehot_encoded = onehot_encoder.fit_transform(labels)
        return onehot_encoded

    def save_weights(self, fileName):
        '''save the weights of your neural network into a file
        Hint: Search python functions for file saving as a .txt'''

        try:
            os.remove(fileName)
        except:
            pass
        file2write = open(fileName, 'w')
        # print(len(self.weights_))
        for i in range(len(self.weights_)):
            # if i == 0:
            #     continue
            # print(i)/
            layer = self.num_layers
            for j in range(self.weights_[i].shape[0]):
                for k in range(self.weights_[i].shape[1]):
                    # print(self.weights_[i][j][k])
                    if i == self.num_layers-2 and j == (self.nodes_per_layer[layer-2]-1) and k == (self.nodes_per_layer[layer-1]-1):
                        file2write.write(str(self.weights_[i][j][k]))
                    else:
                        file2write.write(str(self.weights_[i][j][k])+"\n")
        file2write.close()

    def reassign_weights(self, fileName):
        '''assign the saved weights from the fileName to the network
        Hint: Search python functions for file reading
        '''
        temp_bias = []
        for i in range(30):
            # rnd = np.random.default_rng()
            # val_bias = rnd.uniform(-1, 1)
            val_bias = 0
            temp_bias.append(val_bias)
        self.biases_.append(np.array(temp_bias))
        temp_bias = []
        for i in range(10):
            # rnd = np.random.default_rng()
            # val_bias = rnd.uniform(-1, 1)
            val_bias = 0
            temp_bias.append(val_bias)
        self.biases_.append(np.array(temp_bias))

        f = open(fileName, "r")
        weight1 = []
        weight2 = []

        print("740x30")
        for i in range(self.nodes_per_layer[0]):
            temp = []
            for j in range(self.nodes_per_layer[1]):
                val = f.readline()
                # print(val)
                val = float(val)
                temp.append(val)
                # self.weights_[0][i][j] = val
            temp = np.array(temp)
            weight1.append(temp)
        self.weights_.append(np.array(weight1))
        print("30x10")
        # garbage = f.readline()
        for i in range(self.nodes_per_layer[1]):
            temp = []
            for j in range(self.nodes_per_layer[2]):
                val = f.readline()
                val = float(val)
                # self.weights_[1][i][j] = val
                temp.append(val)
            temp = np.array(temp)
            weight2.append(temp)
        self.weights_.append(np.array(weight2))

        # print(self.weights_[0][1][1])
        # print(self.weights_[1][1][1])

    def savePlot(self, acc, time):
        fig, plots = plt.subplots()
        plots.plot(time, acc)
        plots.set(xlabel='time',
                  ylabel='Accuracy',
                  )
        plots.grid()
        fig.show()
        fig.savefig("plot2.png")

        '''function to plot the execution time versus learning rate plot
        You can edit the parameters pass to the savePlot function'''


def main():
    # time1 = time.time()
    net = NeuralNetwork()
    # net = NeuralNetwork()
    type_data = sys.argv[1]
    data_file = sys.argv[2]
    labels_file = sys.argv[3]
    learning_rate = sys.argv[4]
    # type_file = sys.argv[]

    if type_data == "train":
        # net = NeuralNetwork()
        data, labels = net.give_images(data_file, labels_file)
        data = (data - np.mean(data)) / np.std(data)
        # one_hot_labels = net.generate_labels(labels)
        # print(labels)
        # weights = net.weights_
        hist = net.fit(data, labels, 2, float(learning_rate))
        # print("updating weights")
        net.save_weights("updated_weights.txt")
        # print("history done")
        # oldarr = net.weights_
        # print(net.weights_[0][739][29])

    elif type_data == "test":
        net.weights_ = []
        net.biases_ = []
        net.reassign_weights(learning_rate)
        print("starting")
        data, labels = net.give_images(data_file, labels_file)
        # print(len(net.weights_))
        data = (data - np.mean(data)) / np.std(data)

        loss, acc = net.evaluate(data, labels)

        print("Accuracy:", acc, "%")
        print("Loss", loss)


main()
